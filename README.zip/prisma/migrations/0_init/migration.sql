-- CreateSchema
CREATE SCHEMA IF NOT EXISTS "public";

-- CreateTable
CREATE TABLE "User" (
    "id" TEXT NOT NULL,
    "name" TEXT,
    "university" TEXT,
    "degree" TEXT,
    "department" TEXT,
    "expectedGraduation" TEXT,
    "email" TEXT,
    "linkedin" TEXT,
    "github" TEXT,
    "portfolio" TEXT,
    "country" TEXT,
    "preferredResearchAreas" TEXT,
    "targetCountries" TEXT,
    "internshipDuration" TEXT,
    "preferredStartMonth" TEXT,
    "skills" TEXT,
    "programmingLanguages" TEXT,
    "frameworks" TEXT,
    "researchExperience" TEXT,
    "projects" TEXT,
    "leadershipRoles" TEXT,
    "awards" TEXT,
    "workExperience" TEXT,
    "publications" TEXT,
    "researchInterests" TEXT,
    "technicalStack" TEXT,
    "domainExpertise" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "User_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Professor" (
    "id" TEXT NOT NULL,
    "name" TEXT,
    "university" TEXT,
    "department" TEXT,
    "country" TEXT,
    "email" TEXT,
    "emailStatus" TEXT NOT NULL DEFAULT 'UNVERIFIED',
    "emailSource" TEXT,
    "emailSourceUrl" TEXT,
    "emailConfidence" INTEGER,
    "emailLastChecked" TIMESTAMP(3),
    "position" TEXT,
    "homepage" TEXT,
    "lab" TEXT,
    "rawScrapedText" TEXT,
    "primaryAreas" TEXT,
    "currentThemes" TEXT,
    "keywords" TEXT,
    "openProblems" TEXT,
    "latestPublications" TEXT,
    "mostCitedPublications" TEXT,
    "topicsOverTime" TEXT,
    "currentProjects" TEXT,
    "collaborators" TEXT,
    "phdStudents" TEXT,
    "fundingSources" TEXT,
    "openPositions" TEXT,
    "aiAnalysisSummary" TEXT,
    "status" TEXT NOT NULL DEFAULT 'UNCONTACTED',
    "compatibilityScore" INTEGER,
    "compatibilityReasoning" TEXT,
    "dateSent" TIMESTAMP(3),
    "subject" TEXT,
    "tags" TEXT,
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "userId" TEXT,

    CONSTRAINT "Professor_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "User_email_key" ON "User"("email");

-- AddForeignKey
ALTER TABLE "Professor" ADD CONSTRAINT "Professor_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
